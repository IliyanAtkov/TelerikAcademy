﻿// Create, compile and run a “Hello C#” console application.

using System;


class helloCSharp
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello C#");
    }
}

