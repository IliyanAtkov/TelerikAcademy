﻿// Аpplication that print your name.

using System;


class myName
{
    static void Main(string[] args)
    {
        Console.WriteLine("Pesho");
    }
}

