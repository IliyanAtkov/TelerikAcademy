﻿// Create a console application that prints the current date and time.

using System;



class WhatTimeIsIt
{
    static void Main(string[] args)
    {
        Console.WriteLine(DateTime.Now);
    }
}

