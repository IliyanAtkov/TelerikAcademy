﻿


// Create a console application that calculates and prints the square of the number 12345.

using System;


class SquareOfNumbers
{
    static void Main(string[] args)
    {
        int squareOfNumber = (12345 * 12345);
        Console.WriteLine(squareOfNumber);
    }
}

